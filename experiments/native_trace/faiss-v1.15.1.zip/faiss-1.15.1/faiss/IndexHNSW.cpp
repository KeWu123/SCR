/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

#include <faiss/IndexHNSW.h>

#include <faiss/IndexRaBitQ.h>

#include <atomic>
#include <cinttypes>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include <limits>
#include <memory>
#include <queue>

#include <cstdint>
#include "faiss/Index.h"

#include <faiss/Index2Layer.h>
#include <faiss/IndexFlat.h>
#include <faiss/IndexIVFPQ.h>
#include <faiss/impl/AuxIndexStructures.h>
#include <faiss/impl/FaissAssert.h>
#include <faiss/impl/FaissException.h>
#include <faiss/impl/ResultHandler.h>
#include <faiss/impl/VisitedTable.h>
#include <faiss/impl/hnsw/LockVector.h>
#include <faiss/impl/hnsw/MinimaxHeap.h>
#include <faiss/utils/random.h>
#include <faiss/utils/sorting.h>

namespace faiss {

using storage_idx_t = HNSW::storage_idx_t;
using NodeDistFarther = HNSW::NodeDistFarther;

HNSWStats hnsw_stats;

/**************************************************************
 * add / search blocks of descriptors
 **************************************************************/

namespace {

// Returns the storage's native distance computer. For similarity metrics
// (e.g. METRIC_INNER_PRODUCT), distance values are real similarity scores
// (larger = better); HNSW handles the ordering via `hnsw.is_similarity`.
//
// NOTE: callers that drive the legacy max-heap-only code paths (notably
// `search_from_candidates_2` in the IndexHNSW2Level mixed search) cannot
// consume similarity scores directly; they assume smaller-is-better.
// Those paths only fire for the (default) L2 IndexHNSW2Level + Index2Layer
// configuration today, so passing the native DC is safe in practice.
DistanceComputer* storage_distance_computer(const Index* storage) {
    return storage->get_distance_computer();
}

} // namespace

// Deterministic HNSW graph build inspired by ParlayANN: points are bucketed by
// level and inserted in prefix-doubling batches. Phase A computes forward
// links against a frozen snapshot and records reverse edges; phase B merges
// those in a fixed order.
// https://arxiv.org/abs/2305.04359
void hnsw_add_vertices_deterministic(
        HNSW& hnsw,
        size_t n0,
        size_t n,
        int d,
        bool init_level0,
        bool keep_max_size_level0,
        bool preset_levels,
        bool verbose,
        const std::function<DistanceComputer*()>& make_distance_computer,
        const std::function<void(DistanceComputer&, HNSW::storage_idx_t)>&
                set_query) {
    size_t ntotal = n0 + n;
    double t0 = getmillisecs();
    if (verbose) {
        printf("hnsw_add_vertices_deterministic: adding %zd elements on top of %zd "
               "(preset_levels=%d)\n",
               n,
               n0,
               int(preset_levels));
    }

    if (n == 0) {
        return;
    }

    // init_level0=false (CAGRA import) skips the level-0-only bucket; higher-
    // level points still build their own level-0 links.
    const int min_bucket_level = init_level0 ? 0 : 1;

    int max_level = hnsw.prepare_level_tab(n, preset_levels);
    if (verbose) {
        printf("  max_level = %d\n", max_level);
    }

    // Bucket the new points by level, highest first.
    std::vector<int> hist;
    std::vector<int> order(n);

    { // make buckets with vectors of the same level

        // build histogram
        for (size_t i = 0; i < n; i++) {
            storage_idx_t pt_id = static_cast<storage_idx_t>(i + n0);
            int pt_level = hnsw.levels[pt_id] - 1;
            while (pt_level >= static_cast<int>(hist.size())) {
                hist.push_back(0);
            }
            hist[pt_level]++;
        }

        // accumulate
        std::vector<int> offsets(hist.size() + 1, 0);
        for (size_t i = 0; i < hist.size() - 1; i++) {
            offsets[i + 1] = offsets[i] + hist[i];
        }

        // bucket sort
        for (size_t i = 0; i < n; i++) {
            storage_idx_t pt_id = static_cast<storage_idx_t>(i + n0);
            int pt_level = hnsw.levels[pt_id] - 1;
            order[offsets[pt_level]++] = pt_id;
        }
    }

    // Upper bound on batch size (ParlayANN's theta), 2% of the index.
    const size_t theta =
            std::max<size_t>(1, static_cast<size_t>(0.02 * ntotal));

    // Polled inside phase A: a batch can be 2% of ntotal, so cancelling only
    // at batch boundaries would take minutes on large indexes.
    const idx_t check_period = InterruptCallback::get_period_hint(
            max_level * d * hnsw.efConstruction);

    RandomGenerator rng2(789);
    size_t i1 = n;

    for (int pt_level = static_cast<int>(hist.size()) - 1;
         pt_level >= min_bucket_level;
         pt_level--) {
        size_t i0 = i1 - hist[pt_level];
        if (i0 == i1) {
            continue;
        }

        if (verbose) {
            printf("Adding %zu elements at level %d\n", i1 - i0, pt_level);
        }

        // random permutation to get rid of dataset order bias
        for (size_t j = i0; j < i1; j++) {
            std::swap(
                    order[j],
                    order[j + rng2.rand_int(static_cast<int>(i1 - j))]);
        }

        // Bootstrap only when the graph is empty. Raising entry_point to a
        // point that is not yet linked orphans everything already inserted,
        // which on an incremental add() is the entire prior graph. order[i0]
        // is the sole member of the first batch below, so defer until then.
        bool raise_entry_point = false;
        if (hnsw.entry_point == -1) {
            hnsw.max_level = pt_level;
            hnsw.entry_point = order[i0];
        } else if (pt_level > hnsw.max_level) {
            raise_entry_point = true;
        }

        // Prefix-doubling batches within this bucket.
        size_t s = i0;
        while (s < i1) {
            size_t done = s - i0;
            size_t grow = std::min(done == 0 ? size_t(1) : done, theta);
            size_t e = std::min(i1, s + grow);

            // Phase A: compute forward links against the snapshot
            // A reverse edge: `dest` gains an incoming link from `src`.
            struct Edge {
                int level;
                HNSW::storage_idx_t dest;
                HNSW::storage_idx_t src;
            };

            // One buffer, sized to an upper bound so it never reallocates.
            // The fill order is nondeterministic but harmless: phase B
            // regroups by destination.
            size_t cap_sum = 0;
            for (int64_t i = s; i < static_cast<int64_t>(e); i++) {
                storage_idx_t pid = order[i];
                cap_sum += hnsw.offsets[pid + 1] - hnsw.offsets[pid];
            }
            // Default-initialised to skip a memset per sub-batch; safe because
            // edge_counter only hands out slots that are written before read.
            std::unique_ptr<Edge[]> reverse_edges(new Edge[cap_sum]);
            std::atomic<size_t> edge_counter{0};

            // Thrown after the region (cannot throw out of one); the
            // unsynchronized write costs at most one extra poll.
            bool interrupt = false;

#pragma omp parallel if (e - s > 100)
            {
                std::unique_ptr<VisitedTable> vt =
                        VisitedTable::create(ntotal, hnsw.use_visited_hashset);

                std::unique_ptr<DistanceComputer> dis(make_distance_computer());
                std::vector<std::pair<HNSW::storage_idx_t, int>>
                        pt_reverse_edges;
                size_t counter = 0;

#pragma omp for schedule(static)
                for (int64_t i = s; i < static_cast<int64_t>(e); i++) {
                    if (interrupt) {
                        continue; // cannot break out of an OpenMP for loop
                    }
                    storage_idx_t pt_id = order[i];
                    int lvl = hnsw.levels[pt_id] - 1;
                    set_query(*dis, pt_id);

                    pt_reverse_edges.clear();
                    hnsw.compute_forward_links_deterministic(
                            *dis,
                            lvl,
                            pt_id,
                            *vt,
                            pt_reverse_edges,
                            keep_max_size_level0);

                    size_t off = edge_counter.fetch_add(
                            pt_reverse_edges.size(), std::memory_order_relaxed);
                    for (size_t k = 0; k < pt_reverse_edges.size(); k++) {
                        reverse_edges[off + k] = {
                                pt_reverse_edges[k].second,
                                pt_reverse_edges[k].first,
                                pt_id};
                    }

                    if (counter++ % check_period == 0 &&
                        InterruptCallback::is_interrupted()) {
                        interrupt = true;
                    }
                }
            }
            if (interrupt) {
                FAISS_THROW_MSG("computation interrupted");
            }

            // Phase B: merge the reverse edges
            // Group by destination so each node is merged by exactly one
            // thread: lock-free and thread-count-independent.
            const size_t total = edge_counter.load();

            constexpr int kBucketBits = 8;
            constexpr uint32_t kNumBuckets = 1u << kBucketBits;
            constexpr uint32_t kBucketMask = kNumBuckets - 1;

            // bstart[b]..bstart[b+1] delimits bucket b after partitioning.
            std::vector<size_t> bstart(kNumBuckets + 1, 0);
            for (size_t idx = 0; idx < total; idx++) {
                bstart[(static_cast<uint32_t>(reverse_edges[idx].dest) &
                        kBucketMask) +
                       1]++;
            }
            for (uint32_t b = 0; b < kNumBuckets; b++) {
                bstart[b + 1] += bstart[b];
            }

            // In-place partition (cycle sort): each step lands at least one
            // edge in its bucket, so O(total) with no auxiliary buffer.
            {
                std::vector<size_t> head(bstart.begin(), bstart.end() - 1);
                for (uint32_t b = 0; b < kNumBuckets; b++) {
                    size_t end_b = bstart[b + 1];
                    while (head[b] < end_b) {
                        Edge cur_e = reverse_edges[head[b]];
                        if ((static_cast<uint32_t>(cur_e.dest) & kBucketMask) ==
                            b) {
                            head[b]++;
                            continue;
                        }
                        while ((static_cast<uint32_t>(cur_e.dest) &
                                kBucketMask) != b) {
                            uint32_t tb = static_cast<uint32_t>(cur_e.dest) &
                                    kBucketMask;
                            std::swap(cur_e, reverse_edges[head[tb]]);
                            head[tb]++;
                        }
                        reverse_edges[head[b]] = cur_e;
                        head[b]++;
                    }
                }
            }
            Edge* base = reverse_edges.get();

#pragma omp parallel if (total > 100)
            {
                std::unique_ptr<DistanceComputer> dis(make_distance_computer());
                // Not schedule(dynamic): the libomp dynamic dispatcher
                // segfaults in some build configs.
#pragma omp for schedule(static)
                for (int64_t b = 0; b < static_cast<int64_t>(kNumBuckets);
                     b++) {
                    Edge* p = base + bstart[b];
                    size_t m = bstart[b + 1] - bstart[b];
                    if (m == 0) {
                        continue;
                    }
                    // src order does not matter; the merge re-sorts each set.
                    std::sort(p, p + m, [](const Edge& a, const Edge& c) {
                        if (a.level != c.level) {
                            return a.level < c.level;
                        }
                        return a.dest < c.dest;
                    });
                    std::vector<HNSW::storage_idx_t> incoming;
                    size_t g = 0;
                    while (g < m) {
                        size_t h = g + 1;
                        while (h < m && p[h].level == p[g].level &&
                               p[h].dest == p[g].dest) {
                            h++;
                        }
                        incoming.clear();
                        incoming.reserve(h - g);
                        for (size_t kk = g; kk < h; kk++) {
                            incoming.push_back(p[kk].src);
                        }
                        hnsw.merge_reverse_links_deterministic(
                                *dis,
                                p[g].dest,
                                p[g].level,
                                incoming,
                                keep_max_size_level0 && (p[g].level == 0));
                        g = h;
                    }
                }
            }

            InterruptCallback::check();
            s = e;

            if (raise_entry_point) {
                hnsw.max_level = pt_level;
                hnsw.entry_point = order[i0];
                raise_entry_point = false;
            }
        }

        i1 = i0;
    }

    if (init_level0) {
        FAISS_ASSERT(i1 == 0);
    } else {
        FAISS_ASSERT((i1 - hist[0]) == 0);
    }

    if (verbose) {
        printf("Done in %.3f ms\n", getmillisecs() - t0);
    }
}

/**************************************************************
 * IndexHNSW implementation
 **************************************************************/

IndexHNSW::IndexHNSW(int d_in, int M, MetricType metric)
        : Index(d_in, metric), hnsw(M) {
    hnsw.is_similarity = is_similarity_metric(metric);
}

IndexHNSW::IndexHNSW(Index* storage_in, int M)
        : Index(storage_in->d, storage_in->metric_type),
          hnsw(M),
          storage(storage_in) {
    metric_arg = storage->metric_arg;
    hnsw.is_similarity = is_similarity_metric(metric_type);
}

IndexHNSW::~IndexHNSW() {
    if (own_fields) {
        delete storage;
    }
}

void IndexHNSW::train(idx_t n, const float* x) {
    FAISS_THROW_IF_NOT_MSG(
            storage,
            "Please use IndexHNSWFlat (or variants) instead of IndexHNSW directly");
    // hnsw structure does not require training
    storage->train(n, x);
    is_trained = true;
}

namespace {

template <class BlockResultHandler>
void hnsw_search(
        const IndexHNSW* index,
        idx_t n,
        const float* x,
        BlockResultHandler& bres,
        const SearchParameters* params) {
    FAISS_THROW_IF_NOT_MSG(
            index->storage,
            "No storage index, please use IndexHNSWFlat (or variants) "
            "instead of IndexHNSW directly");
    const HNSW& hnsw = index->hnsw;

    int efSearch = hnsw.efSearch;
    if (params) {
        if (const SearchParametersHNSW* hnsw_params =
                    dynamic_cast<const SearchParametersHNSW*>(params)) {
            efSearch = hnsw_params->efSearch;
        }
    }
    size_t n1 = 0, n2 = 0, ndis = 0, nhops = 0;
    size_t n_rabitq_1bit = 0, n_rabitq_refine = 0;

    idx_t check_period = InterruptCallback::get_period_hint(
            hnsw.max_level * index->d * efSearch);

    for (idx_t i0 = 0; i0 < n; i0 += check_period) {
        idx_t i1 = std::min(i0 + check_period, n);
        std::exception_ptr ex;
        std::atomic<bool> interrupt{false};

#pragma omp parallel if (i1 - i0 > 1)
        {
            VisitedTable* vt = nullptr;
            std::unique_ptr<typename BlockResultHandler::SingleResultHandler>
                    res;
            std::unique_ptr<DistanceComputer> dis;
            try {
                vt = &VisitedTable::get_reusable(
                        index->ntotal, hnsw.use_visited_hashset);
                res = std::make_unique<
                        typename BlockResultHandler::SingleResultHandler>(bres);
                dis.reset(storage_distance_computer(index->storage));
            } catch (...) {
                omp_capture_exception(ex, [&] { interrupt = true; });
            }

#pragma omp for reduction(                                               \
                + : n1, n2, ndis, nhops, n_rabitq_1bit, n_rabitq_refine) \
        schedule(guided)
            for (idx_t i = i0; i < i1; i++) {
                if (interrupt.load(std::memory_order_relaxed)) {
                    continue;
                }
                try {
                    res->begin(i);
                    dis->set_query(x + i * index->d);
                    auto* rq = dynamic_cast<RaBitQDistanceComputer*>(dis.get());
                    if (rq) {
                        rq->stats.reset();
                    }

                    HNSWStats stats =
                            hnsw.search(*dis, index, *res, *vt, params);
                    n1 += stats.n1;
                    n2 += stats.n2;
                    ndis += stats.ndis;
                    nhops += stats.nhops;
                    if (rq) {
                        n_rabitq_1bit += rq->stats.n_1bit;
                        n_rabitq_refine += rq->stats.n_refine;
                    }
                    res->end();
                    vt->advance();
                } catch (...) {
                    omp_capture_exception(ex, [&] { interrupt = true; });
                }
            }
        }
        omp_rethrow_if_exception(ex);
        InterruptCallback::check();
    }

    hnsw_stats.combine({n1, n2, ndis, nhops});
    rabitq_stats.add({n_rabitq_1bit, n_rabitq_refine});
}

} // anonymous namespace

void IndexHNSW::search(
        idx_t n,
        const float* x,
        idx_t k,
        float* distances,
        idx_t* labels,
        const SearchParameters* params) const {
    FAISS_THROW_IF_NOT(k > 0);

    if (is_similarity_metric(this->metric_type)) {
        using RH = HeapBlockResultHandler<HNSW::C_similarity>;
        RH bres(n, distances, labels, k);
        hnsw_search(this, n, x, bres, params);
    } else {
        using RH = HeapBlockResultHandler<HNSW::C_distance>;
        RH bres(n, distances, labels, k);
        hnsw_search(this, n, x, bres, params);
    }
}

void IndexHNSW::range_search(
        idx_t n,
        const float* x,
        float radius,
        RangeSearchResult* result,
        const SearchParameters* params) const {
    if (is_similarity_metric(metric_type)) {
        using RH = RangeSearchBlockResultHandler<HNSW::C_similarity>;
        RH bres(result, radius);
        hnsw_search(this, n, x, bres, params);
    } else {
        using RH = RangeSearchBlockResultHandler<HNSW::C_distance>;
        RH bres(result, radius);
        hnsw_search(this, n, x, bres, params);
    }
}

void IndexHNSW::search1(
        const float* x,
        ResultHandler& handler,
        SearchParameters* params) const {
    if (is_similarity_metric(metric_type)) {
        SingleQueryBlockResultHandler<HNSW::C_similarity, false> bres(handler);
        hnsw_search(this, 1, x, bres, params);
    } else {
        SingleQueryBlockResultHandler<HNSW::C_distance, false> bres(handler);
        hnsw_search(this, 1, x, bres, params);
    }
}

void IndexHNSW::add(idx_t n, const float* x) {
    FAISS_THROW_IF_NOT_MSG(
            storage,
            "Please use IndexHNSWFlat (or variants) instead of IndexHNSW directly");
    FAISS_THROW_IF_NOT(is_trained);
    size_t n0 = ntotal;
    storage->add(n, x);
    ntotal = storage->ntotal;

    bool preset_levels = hnsw.levels.size() == static_cast<size_t>(ntotal);

    hnsw_add_vertices_deterministic(
            hnsw,
            n0,
            n,
            d,
            init_level0,
            keep_max_size_level0,
            preset_levels,
            verbose,
            [this] { return storage_distance_computer(storage); },
            [this, x, n0](DistanceComputer& dc, HNSW::storage_idx_t pt_id) {
                dc.set_query(x + (pt_id - n0) * d);
            });
}

void IndexHNSW::reset() {
    hnsw.reset();
    storage->reset();
    ntotal = 0;
}

void IndexHNSW::reconstruct(idx_t key, float* recons) const {
    storage->reconstruct(key, recons);
}

/**************************************************************
 * This section of functions were used during the development of HNSW support.
 * They may be useful in the future but are dormant for now, and thus are not
 * unit tested at the moment.
 * shrink_level_0_neighbors
 * search_level_0
 * init_level_0_from_knngraph
 * init_level_0_from_entry_points
 * reorder_links
 * link_singletons
 **************************************************************/
void IndexHNSW::shrink_level_0_neighbors(int new_size) {
#pragma omp parallel
    {
        std::unique_ptr<DistanceComputer> dis(
                storage_distance_computer(storage));

#pragma omp for
        for (idx_t i = 0; i < ntotal; i++) {
            size_t begin, end;
            hnsw.neighbor_range(i, 0, &begin, &end);

            std::priority_queue<NodeDistFarther> initial_list;

            for (size_t j = begin; j < end; j++) {
                int v1 = hnsw.neighbors[j];
                if (v1 < 0) {
                    break;
                }
                initial_list.emplace(dis->symmetric_dis(i, v1), v1);

                // initial_list.emplace(qdis(v1), v1);
            }

            std::vector<NodeDistFarther> shrunk_list;
            HNSW::shrink_neighbor_list(
                    *dis, initial_list, shrunk_list, new_size);

            for (size_t j = begin; j < end; j++) {
                if (j - begin < shrunk_list.size()) {
                    hnsw.neighbors[j] = shrunk_list[j - begin].id;
                } else {
                    hnsw.neighbors[j] = -1;
                }
            }
        }
    }
}

void IndexHNSW::search_level_0(
        idx_t n,
        const float* x,
        idx_t k,
        const storage_idx_t* nearest,
        const float* nearest_d,
        float* distances,
        idx_t* labels,
        int nprobe,
        int search_type,
        const SearchParameters* params) const {
    FAISS_THROW_IF_NOT(k > 0);
    FAISS_THROW_IF_NOT(nprobe > 0);

    size_t hnsw_ntotal = hnsw.levels.size();

    auto run = [&]<class C>() {
        using RH = HeapBlockResultHandler<C>;
        RH bres(n, distances, labels, k);

        std::exception_ptr ex;
        std::atomic<bool> interrupt{false};
#pragma omp parallel
        {
            std::unique_ptr<DistanceComputer> qdis;
            HNSWStats search_stats;
            RaBitQStats rq_search_stats;
            VisitedTable* vt = nullptr;
            std::unique_ptr<typename RH::SingleResultHandler> res;
            try {
                qdis.reset(storage_distance_computer(storage));
                vt = &VisitedTable::get_reusable(
                        hnsw_ntotal, hnsw.use_visited_hashset);
                res = std::make_unique<typename RH::SingleResultHandler>(bres);
            } catch (...) {
                omp_capture_exception(ex, [&] { interrupt = true; });
            }

#pragma omp for
            for (idx_t i = 0; i < n; i++) {
                if (interrupt.load(std::memory_order_relaxed)) {
                    continue;
                }
                try {
                    res->begin(i);
                    qdis->set_query(x + i * d);
                    auto* rq =
                            dynamic_cast<RaBitQDistanceComputer*>(qdis.get());
                    if (rq) {
                        rq->stats.reset();
                    }

                    hnsw.search_level_0(
                            *qdis.get(),
                            *res,
                            nprobe,
                            nearest + i * nprobe,
                            nearest_d + i * nprobe,
                            search_type,
                            search_stats,
                            *vt,
                            params);
                    if (rq) {
                        rq_search_stats.add(rq->stats);
                    }
                    res->end();
                    vt->advance();
                } catch (...) {
                    omp_capture_exception(ex, [&] { interrupt = true; });
                }
            }
#pragma omp critical
            {
                hnsw_stats.combine(search_stats);
                rabitq_stats.add(rq_search_stats);
            }
        }
        omp_rethrow_if_exception(ex);
    };

    if (is_similarity_metric(this->metric_type)) {
        run.template operator()<HNSW::C_similarity>();
    } else {
        run.template operator()<HNSW::C_distance>();
    }
}

void IndexHNSW::init_level_0_from_knngraph(
        int k,
        const float* D,
        const idx_t* I) {
    int dest_size = hnsw.nb_neighbors(0);

#pragma omp parallel for
    for (idx_t i = 0; i < ntotal; i++) {
        DistanceComputer* qdis = storage_distance_computer(storage);
        std::vector<float> vec(d);
        storage->reconstruct(i, vec.data());
        qdis->set_query(vec.data());

        std::priority_queue<NodeDistFarther> initial_list;

        for (int j = 0; j < k; j++) {
            int v1 = static_cast<int>(I[i * k + j]);
            if (v1 == i) {
                continue;
            }
            if (v1 < 0) {
                break;
            }
            initial_list.emplace(D[i * k + j], v1);
        }

        std::vector<NodeDistFarther> shrunk_list;
        HNSW::shrink_neighbor_list(*qdis, initial_list, shrunk_list, dest_size);

        size_t begin, end;
        hnsw.neighbor_range(i, 0, &begin, &end);

        for (size_t j = begin; j < end; j++) {
            if (j - begin < shrunk_list.size()) {
                hnsw.neighbors[j] = shrunk_list[j - begin].id;
            } else {
                hnsw.neighbors[j] = -1;
            }
        }
    }
}

void IndexHNSW::init_level_0_from_entry_points(
        int n,
        const storage_idx_t* points,
        const storage_idx_t* nearests) {
    LockVector locks(ntotal);

#pragma omp parallel
    {
        std::unique_ptr<VisitedTable> vt =
                VisitedTable::create(ntotal, hnsw.use_visited_hashset);

        std::unique_ptr<DistanceComputer> dis(
                storage_distance_computer(storage));
        std::vector<float> vec(storage->d);

#pragma omp for schedule(dynamic)
        for (int i = 0; i < n; i++) {
            storage_idx_t pt_id = points[i];
            storage_idx_t nearest = nearests[i];
            storage->reconstruct(pt_id, vec.data());
            dis->set_query(vec.data());

            hnsw.add_links_starting_from(
                    *dis, pt_id, nearest, (*dis)(nearest), 0, locks, *vt);

            if (verbose && i % 10000 == 0) {
                printf("  %d / %d\r", i, n);
                fflush(stdout);
            }
        }
    }
    if (verbose) {
        printf("\n");
    }
}

void IndexHNSW::reorder_links() {
    int M = hnsw.nb_neighbors(0);

#pragma omp parallel
    {
        std::vector<float> distances(M);
        std::vector<size_t> order(M);
        std::vector<storage_idx_t> tmp(M);
        std::unique_ptr<DistanceComputer> dis(
                storage_distance_computer(storage));

#pragma omp for
        for (storage_idx_t i = 0; i < ntotal; i++) {
            size_t begin, end;
            hnsw.neighbor_range(i, 0, &begin, &end);

            for (size_t j = begin; j < end; j++) {
                storage_idx_t nj = hnsw.neighbors[j];
                if (nj < 0) {
                    end = j;
                    break;
                }
                distances[j - begin] = dis->symmetric_dis(i, nj);
                tmp[j - begin] = nj;
            }

            fvec_argsort(end - begin, distances.data(), order.data());
            for (size_t j = begin; j < end; j++) {
                hnsw.neighbors[j] = tmp[order[j - begin]];
            }
        }
    }
}

void IndexHNSW::link_singletons() {
    printf("search for singletons\n");

    std::vector<bool> seen(ntotal);

    for (idx_t i = 0; i < ntotal; i++) {
        size_t begin, end;
        hnsw.neighbor_range(i, 0, &begin, &end);
        for (size_t j = begin; j < end; j++) {
            storage_idx_t ni = hnsw.neighbors[j];
            if (ni >= 0) {
                seen[ni] = true;
            }
        }
    }

    int n_sing = 0, n_sing_l1 = 0;
    std::vector<storage_idx_t> singletons;
    for (storage_idx_t i = 0; i < ntotal; i++) {
        if (!seen[i]) {
            singletons.push_back(i);
            n_sing++;
            if (hnsw.levels[i] > 1) {
                n_sing_l1++;
            }
        }
    }

    printf("  Found %d / %" PRId64 " singletons (%d appear in a level above)\n",
           n_sing,
           ntotal,
           n_sing_l1);

    std::vector<float> recons(singletons.size() * d);
    for (size_t i = 0; i < singletons.size(); i++) {
        FAISS_ASSERT(false); // not implemented
    }
}

void IndexHNSW::permute_entries(const idx_t* perm) {
    auto flat_storage = dynamic_cast<IndexFlatCodes*>(storage);
    FAISS_THROW_IF_NOT_MSG(
            flat_storage, "don't know how to permute this index");
    flat_storage->permute_entries(perm);
    hnsw.permute_entries(perm);
}

DistanceComputer* IndexHNSW::get_distance_computer() const {
    return storage->get_distance_computer();
}

/**************************************************************
 * IndexHNSWFlat implementation
 **************************************************************/

IndexHNSWFlat::IndexHNSWFlat() {
    is_trained = true;
}

IndexHNSWFlat::IndexHNSWFlat(int d_in, int M, MetricType metric)
        : IndexHNSW(
                  (metric == METRIC_L2) ? new IndexFlatL2(d_in)
                                        : new IndexFlat(d_in, metric),
                  M) {
    own_fields = true;
    is_trained = true;
}

/**************************************************************
 * IndexHNSWFlatPanorama implementation
 **************************************************************/

IndexHNSWFlatPanorama::IndexHNSWFlatPanorama()
        : IndexHNSWFlat(),
          cum_sums(),
          pano(sizeof(float), 1, 1),
          num_panorama_levels(0) {}

IndexHNSWFlatPanorama::IndexHNSWFlatPanorama(
        int d_in,
        int M,
        int num_panorama_levels_in,
        MetricType metric)
        : IndexHNSWFlat(d_in, M, metric),
          cum_sums(),
          pano(d_in * sizeof(float), num_panorama_levels_in, 1),
          num_panorama_levels(num_panorama_levels_in) {
    // For now, we only support L2 distance.
    // Supporting dot product and cosine distance is a trivial addition
    // left for future work.
    FAISS_THROW_IF_NOT(metric == METRIC_L2);

    // Enable Panorama search mode.
    // This is not ideal, but is still more simple than making a subclass of
    // HNSW and overriding the search logic.
    hnsw.search_method = HNSW::SM_PANORAMA;
}

void IndexHNSWFlatPanorama::add(idx_t n, const float* x) {
    idx_t n0 = ntotal;
    cum_sums.resize((ntotal + n) * (pano.n_levels + 1));
    pano.compute_cumulative_sums(cum_sums.data(), n0, n, x);
    IndexHNSWFlat::add(n, x);
}

void IndexHNSWFlatPanorama::reset() {
    cum_sums.clear();
    IndexHNSWFlat::reset();
}

void IndexHNSWFlatPanorama::permute_entries(const idx_t* perm) {
    std::vector<float> new_cum_sums(ntotal * (pano.n_levels + 1));

    for (idx_t i = 0; i < ntotal; i++) {
        idx_t src = perm[i];
        memcpy(&new_cum_sums[i * (pano.n_levels + 1)],
               &cum_sums[src * (pano.n_levels + 1)],
               (pano.n_levels + 1) * sizeof(float));
    }

    std::swap(cum_sums, new_cum_sums);
    IndexHNSWFlat::permute_entries(perm);
}

/**************************************************************
 * IndexHNSWPQ implementation
 **************************************************************/

IndexHNSWPQ::IndexHNSWPQ() = default;

IndexHNSWPQ::IndexHNSWPQ(
        int d_in,
        int pq_m,
        int M,
        int pq_nbits,
        MetricType metric)
        : IndexHNSW(new IndexPQ(d_in, pq_m, pq_nbits, metric), M) {
    own_fields = true;
    is_trained = false;
}

void IndexHNSWPQ::train(idx_t n, const float* x) {
    IndexHNSW::train(n, x);
    (dynamic_cast<IndexPQ*>(storage))->pq.compute_sdc_table();
}

/**************************************************************
 * IndexHNSWSQ implementation
 **************************************************************/

IndexHNSWSQ::IndexHNSWSQ(
        int d_in,
        ScalarQuantizer::QuantizerType qtype,
        int M,
        MetricType metric)
        : IndexHNSW(new IndexScalarQuantizer(d_in, qtype, metric), M) {
    is_trained = this->storage->is_trained;
    own_fields = true;
}

IndexHNSWSQ::IndexHNSWSQ() = default;

/**************************************************************
 * IndexHNSWRaBitQ implementation
 **************************************************************/

IndexHNSWRaBitQ::IndexHNSWRaBitQ() = default;

namespace {

IndexRaBitQ* make_hnsw_rabitq_storage(
        int d,
        uint8_t nb_bits,
        MetricType metric) {
    FAISS_THROW_IF_NOT_MSG(
            metric == METRIC_L2, "IndexHNSWRaBitQ supports only the L2 metric");
    return new IndexRaBitQ(d, metric, nb_bits);
}

} // namespace

IndexHNSWRaBitQ::IndexHNSWRaBitQ(
        int d,
        int M,
        uint8_t nb_bits,
        MetricType metric)
        : IndexHNSW(make_hnsw_rabitq_storage(d, nb_bits, metric), M) {
    own_fields = true;
    is_trained = storage->is_trained;
    // 1-bit codes store plain SignBitFactors with no f_error, so there is no
    // bound to prune with and the staged path does not apply.
    hnsw.search_method = nb_bits >= 2 ? HNSW::SM_RABITQ : HNSW::SM_DEFAULT;
}

/**************************************************************
 * IndexHNSW2Level implementation
 **************************************************************/

IndexHNSW2Level::IndexHNSW2Level(
        Index* quantizer,
        size_t nlist,
        int m_pq,
        int M)
        : IndexHNSW(new Index2Layer(quantizer, nlist, m_pq), M) {
    own_fields = true;
    is_trained = false;
}

IndexHNSW2Level::IndexHNSW2Level() = default;

namespace {

// same as search_from_candidates but uses v
// visno -> is in result list
// visno + 1 -> in result list + in candidates
int search_from_candidates_2(
        const HNSW& hnsw,
        DistanceComputer& qdis,
        int k,
        idx_t* I,
        float* D,
        MinimaxHeap& candidates,
        VisitedTableVector& vt,
        HNSWStats& stats,
        int level,
        int nres_in = 0) {
    int nres = nres_in;
    for (int i = 0; i < candidates.size(); i++) {
        idx_t v1 = candidates.ids[i];
        FAISS_ASSERT(v1 >= 0);
        vt.visited[v1] = vt.visno + 1;
    }

    int nstep = 0;

    while (candidates.size() > 0) {
        float d0 = 0;
        int v0 = candidates.pop_min(&d0);

        size_t begin, end;
        hnsw.neighbor_range(v0, level, &begin, &end);

        for (size_t j = begin; j < end; j++) {
            int v1 = hnsw.neighbors[j];
            if (v1 < 0) {
                break;
            }
            if (vt.visited[v1] == vt.visno + 1) {
                // nothing to do
            } else {
                float d = qdis(v1);
                candidates.push(v1, d);

                // never seen before --> add to heap
                if (vt.visited[v1] < vt.visno) {
                    if (nres < k) {
                        faiss::maxheap_push(++nres, D, I, d, v1);
                    } else if (d < D[0]) {
                        faiss::maxheap_replace_top(nres, D, I, d, v1);
                    }
                }
                vt.visited[v1] = vt.visno + 1;
            }
        }

        nstep++;
        if (nstep > hnsw.efSearch) {
            break;
        }
    }

    stats.n1++;
    if (candidates.size() == 0) {
        stats.n2++;
    }

    return nres;
}

} // namespace

void IndexHNSW2Level::search(
        idx_t n,
        const float* x,
        idx_t k,
        float* distances,
        idx_t* labels,
        const SearchParameters* params) const {
    FAISS_THROW_IF_NOT(k > 0);
    FAISS_THROW_IF_MSG(params, "search params not supported for this index");

    if (dynamic_cast<const Index2Layer*>(storage)) {
        IndexHNSW::search(n, x, k, distances, labels);

    } else { // "mixed" search
        size_t n1 = 0, n2 = 0, ndis = 0, nhops = 0;

        const IndexIVFPQ* index_ivfpq =
                dynamic_cast<const IndexIVFPQ*>(storage);
        FAISS_THROW_IF_NOT_MSG(
                index_ivfpq,
                "IndexHNSW2Level mixed search requires IndexIVFPQ storage");

        size_t nprobe = index_ivfpq->nprobe;

        std::unique_ptr<idx_t[]> coarse_assign(new idx_t[n * nprobe]);
        std::unique_ptr<float[]> coarse_dis(new float[n * nprobe]);

        index_ivfpq->quantizer->search(
                n, x, nprobe, coarse_dis.get(), coarse_assign.get());

        index_ivfpq->search_preassigned(
                n,
                x,
                k,
                coarse_assign.get(),
                coarse_dis.get(),
                distances,
                labels,
                false);

        std::exception_ptr ex;
        std::atomic<bool> interrupt{false};
#pragma omp parallel
        {
            // visited table (not hash set) for tri-state flags.
            std::unique_ptr<VisitedTable> vt;
            std::unique_ptr<DistanceComputer> dis;
            constexpr int candidates_size = 1;
            std::unique_ptr<MinimaxHeap> candidates;
            try {
                vt = VisitedTable::create(ntotal, /*use_hashset=*/false);
                dis.reset(storage_distance_computer(storage));
                candidates = std::make_unique<MinimaxHeap>(candidates_size);
            } catch (...) {
                omp_capture_exception(ex, [&] { interrupt = true; });
            }

#pragma omp for reduction(+ : n1, n2, ndis, nhops)
            for (idx_t i = 0; i < n; i++) {
                if (interrupt.load(std::memory_order_relaxed)) {
                    continue;
                }
                try {
                    idx_t* idxi = labels + i * k;
                    float* simi = distances + i * k;
                    dis->set_query(x + i * d);

                    // mark all inverted list elements as visited
                    for (size_t j = 0; j < nprobe; j++) {
                        idx_t key = coarse_assign[j + i * nprobe];
                        if (key < 0) {
                            break;
                        }
                        size_t list_length = index_ivfpq->get_list_size(key);
                        const idx_t* ids = index_ivfpq->invlists->get_ids(key);

                        for (size_t jj = 0; jj < list_length; jj++) {
                            vt->set(ids[jj]);
                        }
                    }

                    candidates->clear();

                    for (int j = 0; j < k; j++) {
                        if (idxi[j] < 0) {
                            break;
                        }
                        candidates->push(
                                static_cast<storage_idx_t>(idxi[j]), simi[j]);
                    }

                    // reorder from sorted to heap
                    maxheap_heapify(k, simi, idxi, simi, idxi, k);

                    HNSWStats search_stats;
                    search_from_candidates_2(
                            hnsw,
                            *dis,
                            k,
                            idxi,
                            simi,
                            *candidates,
                            static_cast<VisitedTableVector&>(*vt),
                            search_stats,
                            0,
                            k);
                    n1 += search_stats.n1;
                    n2 += search_stats.n2;
                    ndis += search_stats.ndis;
                    nhops += search_stats.nhops;

                    vt->advance();
                    vt->advance();

                    maxheap_reorder(k, simi, idxi);
                } catch (...) {
                    omp_capture_exception(ex, [&] { interrupt = true; });
                }
            }
        }
        omp_rethrow_if_exception(ex);

        hnsw_stats.combine({n1, n2, ndis, nhops});
    }
}

void IndexHNSW2Level::flip_to_ivf() {
    Index2Layer* storage2l = dynamic_cast<Index2Layer*>(storage);

    FAISS_THROW_IF_NOT(storage2l);

    IndexIVFPQ* index_ivfpq = new IndexIVFPQ(
            storage2l->q1.quantizer,
            d,
            storage2l->q1.nlist,
            storage2l->pq.M,
            8);
    index_ivfpq->pq = storage2l->pq;
    index_ivfpq->is_trained = storage2l->is_trained;
    index_ivfpq->precompute_table();
    index_ivfpq->own_fields = storage2l->q1.own_fields;
    storage2l->transfer_to_IVFPQ(*index_ivfpq);
    index_ivfpq->make_direct_map(true);

    storage = index_ivfpq;
    delete storage2l;
}

/**************************************************************
 * IndexHNSWCagra implementation
 **************************************************************/

IndexHNSWCagra::IndexHNSWCagra() {
    is_trained = true;
}

IndexHNSWCagra::IndexHNSWCagra(
        int d_in,
        int M,
        MetricType metric,
        NumericType numeric_type)
        : IndexHNSW(d_in, M, metric) {
    FAISS_THROW_IF_NOT_MSG(
            ((metric == METRIC_L2) || (metric == METRIC_INNER_PRODUCT)),
            "unsupported metric type for IndexHNSWCagra");
    numeric_type_ = numeric_type;
    if (numeric_type == NumericType::Float32) {
        // Use flat storage with full precision for fp32
        storage = (metric == METRIC_L2)
                ? static_cast<Index*>(new IndexFlatL2(d))
                : static_cast<Index*>(new IndexFlatIP(d));
    } else if (numeric_type == NumericType::Float16) {
        auto qtype = ScalarQuantizer::QT_fp16;
        storage = new IndexScalarQuantizer(d, qtype, metric);
    } else {
        FAISS_THROW_MSG(
                "Unsupported numeric_type: only F16 and F32 are supported for IndexHNSWCagra");
    }

    metric_arg = storage->metric_arg;

    own_fields = true;
    is_trained = true;
    init_level0 = true;
    keep_max_size_level0 = true;
}

void IndexHNSWCagra::add(idx_t n, const float* x) {
    FAISS_THROW_IF_MSG(
            base_level_only,
            "Cannot add vectors when base_level_only is set to True");

    IndexHNSW::add(n, x);
}

void IndexHNSWCagra::search(
        idx_t n,
        const float* x,
        idx_t k,
        float* distances,
        idx_t* labels,
        const SearchParameters* params) const {
    if (!base_level_only) {
        IndexHNSW::search(n, x, k, distances, labels, params);
    } else {
        if (ntotal == 0) {
            std::fill(
                    distances,
                    distances + n * k,
                    std::numeric_limits<float>::max());
            std::fill(labels, labels + n * k, -1);
            return;
        }
        std::vector<storage_idx_t> nearest(n);
        std::vector<float> nearest_d(n);

        auto pick_entrypoints = [&]<class C>() {
#pragma omp parallel for
            for (idx_t i = 0; i < n; i++) {
                std::unique_ptr<DistanceComputer> dis(
                        storage_distance_computer(this->storage));
                dis->set_query(x + i * d);
                nearest[i] = -1;
                // C::neutral() is the "worst possible" value: +inf for
                // CMax (distance) and -inf for CMin (similarity). The
                // first real candidate will always be strictly better.
                nearest_d[i] = C::neutral();

                // Seeded per query so entrypoints are reproducible.
                SplitMix64RandomGenerator gen(i);

                for (idx_t j = 0; j < num_base_level_search_entrypoints; j++) {
                    idx_t idx = gen.rand_int64() % this->ntotal;
                    auto distance = (*dis)(idx);
                    if (C::cmp(nearest_d[i], distance)) {
                        nearest[i] = static_cast<storage_idx_t>(idx);
                        nearest_d[i] = distance;
                    }
                }
                FAISS_THROW_IF_NOT_MSG(
                        nearest[i] >= 0, "Could not find a valid entrypoint.");
            }
        };

        if (is_similarity_metric(metric_type)) {
            pick_entrypoints.template operator()<HNSW::C_similarity>();
        } else {
            pick_entrypoints.template operator()<HNSW::C_distance>();
        }

        search_level_0(
                n,
                x,
                k,
                nearest.data(),
                nearest_d.data(),
                distances,
                labels,
                1, // n_probes
                1, // search_type
                params);
    }
}

void IndexHNSWCagra::range_search(
        idx_t n,
        const float* x,
        float radius,
        RangeSearchResult* result,
        const SearchParameters* params) const {
    if (!base_level_only) {
        IndexHNSW::range_search(n, x, radius, result, params);
        return;
    }

    auto run = [&]<class C>() {
        const HNSW& hnsw = this->hnsw;
        size_t n1 = 0, n2 = 0, ndis = 0, nhops = 0;
        RangeSearchPartialResult pres(result);

        for (idx_t i = 0; i < n; i++) {
            std::unique_ptr<DistanceComputer> dis(
                    storage_distance_computer(storage));
            dis->set_query(x + i * d);

            storage_idx_t nearest = -1;
            // C::neutral() is the "worst possible" value under C: +inf for
            // CMax (distance) and -inf for CMin (similarity). The first
            // real candidate will always be strictly better.
            float nearest_d = C::neutral();

            // For reproducible entrypoint.
            SplitMix64RandomGenerator gen(i);

            for (idx_t j = 0; j < num_base_level_search_entrypoints; j++) {
                idx_t idx = gen.rand_int64() % ntotal;
                auto distance = (*dis)(idx);
                // C::cmp(nearest_d, distance) is true iff distance is
                // strictly better than the current nearest_d.
                if (C::cmp(nearest_d, distance)) {
                    nearest = idx;
                    nearest_d = distance;
                }
            }
            FAISS_THROW_IF_NOT_MSG(
                    nearest >= 0, "Could not find a valid entrypoint.");

            RangeQueryResult& qres = pres.new_result(i);
            RangeResultHandler<C> res(&qres, radius);
            VisitedTable& vt = VisitedTable::get_reusable(
                    ntotal, hnsw.use_visited_hashset);
            HNSWStats stats;
            hnsw.search_level_0(
                    *dis, res, 1, &nearest, &nearest_d, 1, stats, vt, params);
            n1 += stats.n1;
            n2 += stats.n2;
            ndis += stats.ndis;
            nhops += stats.nhops;
        }

        pres.set_lims();
        result->do_allocation();
        pres.copy_result();

        hnsw_stats.combine({n1, n2, ndis, nhops});
    };

    if (is_similarity_metric(metric_type)) {
        run.template operator()<HNSW::C_similarity>();
    } else {
        run.template operator()<HNSW::C_distance>();
    }
}

faiss::NumericType IndexHNSWCagra::get_numeric_type() const {
    return numeric_type_;
}

void IndexHNSWCagra::set_numeric_type(faiss::NumericType numeric_type) {
    numeric_type_ = numeric_type;
}

} // namespace faiss
